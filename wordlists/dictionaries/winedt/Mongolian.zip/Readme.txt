%%
%% mn.dic -- Mongolian language dictionary file
%%
%% Author: Dorjgotov Batmunkh
%% Version: 1.5
%% Date: 2008/03/23
%% Word count: 2,160,886
%%
%% "This dictionary is dedicated to my mother Guntevsuren"
%%
%% This is a Mongolian language dictionary which is provided
%% without any warranty, for natural sciences. The dictionary
%% coded with cp1251 encoding.
%%
%% Copyright (c) 2006-2008 Dorjgotov Batmunkh <bataak@gmail.com>
%% Permission is granted to copy, distribute and/or modify this
%% document under the terms of the GNU Free Documentation License,
%% Version 1.2 or any later version published by the Free Software
%% Foundation; with no Invariant Sections, no Front-Cover Texts,
%% and no Back-Cover Texts. A copy of the license is included in
%% the section entitled "GNU Free Documentation License".
%%

I want to thank the entire WinEdt Team, especially Robert.
