New German Dictionaties

If you're interested read all of this file !!!!!!!!!


I'm not the maintainer of the German dictionaries, but I needed a
new German one. Thus, I did it myself, using all the info I found
on the internet.

If someone has German word-lists with words NOT IN DE_NEU.DIC or
DE_ALT.DIC I'm willing to check them and add them to a new version
of either DE_NEU.DIC or DE_NEU_Addon.DIC -- if it would not be too
time consuming as I have lots of other work to do, too.
Furthermore, I will not split the words and add them to special
dictionaries like ELEKTRONIK.DIC, it's too much effort with only
little use (IMHO).


    e-mail: christian cenker @ univie . ac . at
    home:   http://staff.smc.univie.ac.at/cenker


I recompiled the latest german dictionaries to the 'Neue deutsche
Rechtschreibung' (new German spelling from 1998). Furthermore, I
renamed the German dictionaries using German names only, as IMHO
everybody who uses the German dictionaries should know the German
language. I think we all know what auto-translation programs not
aware of the language produce - at least something to laugh about.
Thus, I'm now switching to German.

Obwohl ich sonst eher anglophil bin - die Umgangs- und
Wissenschaftssprache der Mathematiker, finde ich, wie gesagt, dass
jemand, der die deutschen W�rterb�cher verwendet zumindest so viel
Ahnung vom Deutschen haben soll, das er/sie das hier versteht.


  de_neu.dic  neue deutsche Rechtschreibung
  de_alt.dic  'altes' W�rterbuch = de.dic

  alle anderen Dateien wurden ins Neu-Deutsch �bersetzt
  und umbenannt, d.h., ich verpasste ihnen deutsche Bezeichnungen.

Was ich tat:

Ich nahm die aktuellen (26 April 1999) Versionen der deutschen
W�rterb�cher vom Netz (http://home.istar.ca/~winedt) und lud diese
in MS Word (sorry) und lies den Orthographen von Bertelsmann
dr�berlaufen, wobei ich allerdings alle �nderungen angesehen habe,
da hie und da haarstr�ubende Dinge rausgekommen w�ren.

W�rter, die getrennt und zusammen geschrieben werden
k�nnen/d�rfen/m�ssen (vgl. unten) wurden nur in ihrer zusammen
geschriebenen Form ins W�rterbuch aufgenommen, falls beide Teile
der Getrennt-Schreibung deutsche Worte sind, die bereits im
W�rterbuch sind.

Also, im Zweifelsfalle getrennt schreiben! Das ist fast immer
erlaubt bzw. sinnvoll (vgl. unten)!

Ich habe KEIN remove.dic und addon.dic erzeugt, da ich das
einerseits f�r sinnlos halte, da das W�rterbuch grundlegend
ge�ndert wurde, andererseits auch f�r �berfl�ssig, da WinEdt32
sowieso sch�ne Dateisortierungs- und -vergleichsroutinen
implementiert hat. Weiters finde ich es als dumm, 'eigene' W�rter,
die nicht im W�rterbuch vorhanden sind, unkontrolliert in dieses
zu schreiben. Diese sollten immer in eigene Dateien geschrieben
werden, die den Namen des 'Autors' beinhaltet (sowohl im
Dateinamen, als auch in einem Kommentar in der Datei).


Einige Beispiele neu-deutscher Sprache:
---------------------------------------

Nat�rlich gibt's keine �berpr�fung auf grammatikalisch richtige
Verwendung, wie in:

    Getr�nke kalt stellen
    jemanden kaltstellen

    den Oberk�rper frei machen
    einen Brief freimachen

    trotz weit gehender Vollmachten
    seine Vollmachten waren weitgehender

    ein klein kariertes Heft
    eine kleinkarierte Person

    er ist eine hoch gestellt Pers�nlichkeit
    eine hochgestellte Ziffer im Text

    er hat das Rohr gerade gebogen
    er hat die Situation geradegebogen

    das Schiff klarmachen
    jemanden etwas klar machen

    f�r etwas geradestehen
    aber: er soll gerade stehen, nicht schief

    Allein erziehende M�tter sind Alleinerziehende

    Erholung suchende Touristen sind Erholungsuchende

    Essen warm halten
    sich jemanden warmhalten

    an einem Plan festhalten
    an einem Seil fest halten

    weitgehend recht haben
    er hat weit gehende Vollmachten

Oder: substantivisch Gebrauchtes

    Der Achtziger = der achtzigste Geburtstag


Oder: beides erlaubt:

    aufwendig  von aufwenden
    aufw�ndig  von Aufwand

Weiters: Ich weigere mich Tolpatsch zu streichen, und nur
Tollpatsch aufzunehmen, daher ist auch

    Tolpatsch = ungarischer Fu�soldat (langes O!) im W�rterbuch
    enthalten. Warum werden ungarische Lehnworte anders als
    franz�sische oder englische behandelt? Vielleicht haben da die
    �sterreicher, wie ich einer bin, andere Traditionen ;-)

Vorsicht: �sterreichische Variante

    Erdgeschoss = Ein Geschoss aus Erde (etwa eine Kugel)
    Erdgescho� = Unterstes Gescho� eines Hauses (langes O)


Folgendes verstehe ich nicht, aber folgende Hauptvarianten wurden
von der Rechtschreibkommission empfohlen, obwohl sie den gleichen
Wortstamm haben:

    Fotograph aber Grafiker
