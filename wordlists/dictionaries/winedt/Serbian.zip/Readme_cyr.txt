
This is corrections and additions for existing dictionaris.

This dictionary contain a collection of serbian word in 
cyrillic scripts. This dictionary is made in WinEdt spell 
chacker. The source of the list is book Re\v{c}nik stranih 
re\v{c}i i izraza, author: Milan Vujaklija. This book is 
publishing in Serbia in 1980. I am type this books, in Latex, 
for my own personal reson. Publisher is publisher hause name by 
PROSVETA.   

This dictionary contains just over a 30000 serbian words in 
cyrillic scripts. I try, in the future, that this dictionary 
containg more serbian words.

I hope that dictionary is a usefull for a god TeXnic people. 

My name is: Zoran T. Filipovi� 
email: zoran dot filipovic at yahoo dot com
address: Jurija Gagarina 263/3
city: 11070 Novi Beograd
state: Srbija (Serbia)
 