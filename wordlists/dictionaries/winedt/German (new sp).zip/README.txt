%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% file:    de_neu.dic (de)
% version: 5 Jan 2005
% New German spelling wordlist for WinEdt (or compatible) spellcheckers
% wordcount: 532273 words
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PUBLISHED UNTER THE GNU GENERAL PUBLIC LICENSE
% This wordlist is free; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by the
% Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
% SEE http://www.gnu.org/ FOR DETAILS
%
% Parts of this wordlist are taken from the german ISPELL dictionary
% Thanks to Robert from WinEdt.org for hunting the spellerrors
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

INSTALLATION:

Copy "de_neu_dic" to your WinEdt dictionary folder ([PATH_TO_WINEDT]\Dict\german)
and use WinEdts dictionary manager to activate the dictionary (consult WinEdts
Online-Help for further details)


Maintainer of this wordlist:

   Juergen Vierheilig
EMAil:   info@madservice.de
WWW:  http://www.madservice.de
