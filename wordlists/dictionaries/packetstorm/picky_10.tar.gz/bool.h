#ifndef BOOL_H
#define BOOL_H
typedef int Boolean;
const int TRUE = 1;
const int FALSE = 0;
#endif
